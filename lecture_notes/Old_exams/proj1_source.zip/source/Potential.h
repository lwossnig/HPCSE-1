/*
 *  Potential.h
 *  hpchw
 *
 *  Created by Dmitry Alexeev on 16.10.13.
 *  Copyright 2013 ETH Zurich. All rights reserved.
 *
 */

#pragma once

#include "thrust/detail/config.h"

//**********************************************************************************************************************
// Lennard-Jones
//**********************************************************************************************************************
class LennardJones
{
private:
	double epsx4;
	double epsx24;
	double sigma2;
	double cutoffRad2;
	double cutoffShift;
		
public:
	double cutoffRad;
	inline LennardJones(double, double, double);
	__host__ __device__ inline void   F(const double, const double, const double, double&, double&, double&);
	__host__ __device__ inline double V(const double, const double, const double);
	__host__ __device__ inline double _VnoCut(const double, const double, const double);
};

inline LennardJones::LennardJones(double eps, double sigma, double cutRad):
epsx4(eps*4), epsx24(eps*24), sigma2(sigma*sigma),
cutoffRad(cutRad), cutoffRad2(cutRad * cutRad)
{
	cutoffShift = _VnoCut(0, 0, cutoffRad);
}

__host__ __device__ inline double LennardJones::_VnoCut(const double dx, const double dy, const double dz)
{
	const double r2 = dx*dx + dy*dy + dz*dz;
	
	double relR2 = sigma2 / r2;
	double relR6  = relR2 * relR2 * relR2;
	double relR12 = relR6 * relR6;
	return epsx4 * (relR12 - relR6);
}

__host__ __device__ inline double LennardJones::V(const double dx, const double dy, const double dz)
{
	const double r2 = dx*dx + dy*dy + dz*dz;
	
	if (r2 > cutoffRad2) return 0;
	
	double relR2 = sigma2 / r2;
	double relR6  = relR2 * relR2 * relR2;
	double relR12 = relR6 * relR6;
	return epsx4 * (relR12 - relR6) - cutoffShift;
}

__host__ __device__ inline void LennardJones::F(const double dx, const double dy, const double dz, 
												double& fx,      double& fy,      double& fz)
{
	const double r2 = dx*dx + dy*dy + dz*dz;
	if (r2 > cutoffRad2)
	{
		fx = 0;
		fy = 0;
		fz = 0;
		return;
	}
	
	double r_2 = 1.0 / r2;	
	double relR2  = sigma2 * r_2;
	double relR6  = relR2 * relR2 * relR2;
	double relR12 = relR6 * relR6;
	
	double fAbs = epsx24 * r_2 * (relR6 - 2*relR12);
	fx = fAbs * dx;
	fy = fAbs * dy;	
	fz = fAbs * dz;	
}
