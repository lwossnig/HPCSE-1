/*
 *  proj1.cpp
 *  hpchw
 *
 *  Created by Dmitry Alexeev on 15.10.13.
 *  Copyright 2013 ETH Zurich. All rights reserved.
 *
 */


#include <iostream>
#include <fstream>
#include <list>

#include "timer.h"
#include "ArgumentParser.h"
#include "Simulation.h"
#include "Savers.h"

using namespace std;
using namespace ArgumentParser;

string Saver::folder("");

int main (int argc, char **argv)
{
	int n, iters;
	double eps, sigma, cutRad, energy, dt, endTime, L;
	string folder = "res/";

	n       = 100;
	eps     = 1;
	sigma   = -1;
	cutRad  = -1;
	energy  = 100;
	dt      = 1e-4;
	endTime = 1;
	L       = 2;
	
	const OptionStruct opts[] =
	{
		{'n', "particles",  INT,    "Number of particles",     &n},
		{'t', "dt",         DOUBLE, "Simulation timestep",     &dt},
		{'f', "end_time",   DOUBLE, "End time of simulaiton",  &endTime},
		{'v', "energy",     DOUBLE, "Initial total energy",    &energy},
		{'e', "eps",        DOUBLE, "Epsilon in LJ potential", &eps},
		{'s', "sigma",      DOUBLE, "Sigma in LJ potential",   &sigma},
		{'c', "cutoff",		DOUBLE, "Cutoff in sigma units",   &cutRad},
		{'l', "length",     DOUBLE, "Domain lenght",           &L},
		{'p', "prefix",     STRING, "Result folder",           &folder}		
	};
	
	vector<OptionStruct> vopts(opts, opts + 9);

	Parser parser(vopts);
	parser.parse(argc, argv);
	
	if (sigma  < 0)
	{
		sigma  = pow(1.0/n, 1.0/3.0);
		printf("Sigma is automatically set to %f\n", sigma);
	}
	
	if (cutRad < 0)
	{
		cutRad = 2.5;
		printf("Cut-off is automatically set to %f\n", cutRad);
	}
	cutRad *= sigma;
	
	Saver::makedir(folder + "/");
	SaveEnergy       *enSaver   = new SaveEnergy      ("nrg.txt");
	SavePos          *posSaver  = new SavePos         ("pos.xyz");
	SaveLinMom       *linSaver  = new SaveLinMom      ("lin.txt");
	SaveAngMom		 *angSaver  = new SaveAngMom	  ("ang.txt");
	SaveCenterOfMass *massSaver = new SaveCenterOfMass("mass.txt");
	SaveTiming       *timeSaver = new SaveTiming      (&cout);
	
	Simulation simulation(n, energy, 1, eps, sigma, cutRad, dt, L);
	simulation.registerSaver(enSaver, 100);
	simulation.registerSaver(posSaver, 100);
	simulation.registerSaver(linSaver, 100);
	simulation.registerSaver(angSaver, 100);
	simulation.registerSaver(massSaver, 100);
	simulation.registerSaver(timeSaver, 100);
	simulation.profiler.millisec();
	
	iters = ceil(endTime / dt);
	for (int i=0; i<=iters; i++)
	{
		if (i % 500 == 0) printf("Simulation time is %f\n", i * dt);
		simulation.runOneStep();
	}
}



