/*
 * misc.h
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */

#pragma once

typedef double Real;
