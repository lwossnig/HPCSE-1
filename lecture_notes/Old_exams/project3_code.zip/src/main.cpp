/*
 * main.cpp
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */

#include <mpi.h>
#include <stdio.h>
#include <iostream>

#include "Simulation.h"
#include "ArgumentParser.h"

using namespace std;
using namespace ArgumentParser;

string Saver::folder("");
const int Kernel2D::stencil[] = {-10, 10};

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int nx, ny, iters;
	int width, height, period;
	double dt, endTime, D, eps, f, k;
	string folder = "res/";
	string variant;

	nx      = 100;
	ny      = 100;
	dt      = 1e-4;
	endTime = 1;
	D		= 1;
	eps		= 0.02;
	width   = 600;
	height  = 600;
	period  = 1000;
	f 		= 0.03;
	k		= 0.062;
	variant = "diffusion";

	const OptionStruct opts[] =
	{
			{'x', "nx",  		INT,    "Number of points along x",							&nx},
			{'y', "ny",  		INT,    "Number of points along y",							&ny},
			{'w', "width", 		INT,    "Image width",										&width},
			{'h', "height",		INT,    "Image height",										&height},
			{'r', "period", 	INT,    "Dump image every n timesteps",						&period},
			{'t', "dt",			DOUBLE, "Simulation timestep",								&dt},
			{'f', "end_time",	DOUBLE, "End time of simulation",							&endTime},
			{'d', "diffconst",	DOUBLE, "Diffusion constant",								&D},
			{'e', "epsilon",	DOUBLE, "Epsilon for the kernel",							&eps},
	/*10*/	{'p', "prefix",		STRING, "Folder for results",								&folder},
			{'v', "variant",	STRING, "Simulation type (diffusion, grayscott)",			&variant},
			{'F', "F",			DOUBLE, "Gray Scott parameter F",							&f},
			{'K', "K",			DOUBLE, "Gray Scott parameter k",							&k},
	};

	vector<OptionStruct> vopts(opts, opts + 13);

	int me;
	MPI_Comm_rank(MPI_COMM_WORLD, &me);
	bool silent = (me != 0);
	Parser parser(vopts, silent);
	parser.parse(argc, argv);

	Saver::makedir(folder);
	Kernel2D kernel(eps, 5 * eps);
	Simulation* sim;

	if (variant.compare("diffusion") == 0)
	{
		sim = new Diffusion(nx, ny, -1, 1, -1, 1, dt, kernel, D);
		sim->initialize();
		Saver* saveNorms = new SaveNorms("norms.txt");
		sim->registerSaver(saveNorms, 100);
	}
	else if (variant.compare("grayscott") == 0)
	{
		sim = new GrayScott(nx, ny, -1, 1, -1, 1, dt, kernel, 2e-5, 1e-5, f, k);
		sim->initialize();
	}

	iters = (int)round(endTime / dt);

	SaveTiming saveTiming(&cout);
	sim->registerSaver(&saveTiming, 100);

	Screen scr;
	sim->registerSaver(&scr, 500);

	SavePNG savePNG("img", width, height);
	sim->registerSaver(&savePNG, period);
	savePNG.prepare();

	for (int iter = 0; iter < iters; iter++)
	{
		sim->step();
	}
	sim->postExecSavers();

	MPI_Finalize();
	return 0;
}
