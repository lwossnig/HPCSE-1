/*
 *  Saver.h
 *  rl
 *
 *  Created by Dmitry Alexeev on 24.05.13.
 *  Copyright 2013 ETH Zurich. All rights reserved.
 *
 */

#pragma once

#include <iostream>
#include <fstream>
#include <algorithm>
#include <sys/stat.h>
#include <errno.h>
#include <cmath>

#include "Simulation.h"
#include "Profiler.h"
#include "write_png.h"


using namespace std;

class Simulation;
class Grid2D;
class LocalGrid2D;

class Saver
{
protected:
	int period;
	ofstream* file;
	static string folder;
	Simulation* sim;

public:
	Saver (ostream* cOut) : file((ofstream*)cOut) { };
	Saver (string fname)
	{
		file = new ofstream((this->folder+fname).c_str());
	}
	Saver (){};

	inline  void setSimulation(Simulation* e);
	inline  void setPeriod(int);
	inline  int  getPeriod();

	inline static bool makedir(string name)
	{
		folder = name;
		if (mkdir(folder.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) != 0 && errno != EEXIST) return false;
		return true;
	}

	virtual void exec() = 0;
};

inline void Saver::setPeriod(int p)
{
	period = p;
}

inline int Saver::getPeriod()
{
	return period;
}

inline void Saver::setSimulation(Simulation* s)
{
	sim = s;
}

class SaveNorms : public Saver
{
public:
	SaveNorms(ostream* o)		  : Saver(o) {};
	SaveNorms(string fname)	  : Saver(fname) {};

	void exec();
};

class SaveTiming: public Saver
{
public:
	SaveTiming(ostream* o)		  : Saver(o) {};
	SaveTiming(string fname)	  : Saver(fname) {};

	void exec();
};

class SavePNG: public Saver
{
	string prefix;
	LocalGrid2D* grid;
	int mynx_viz, myny_viz;
	int nx_viz,   ny_viz;
	int ghostx, ghosty;
	int stencil;

	int nQuantities;
	int imgNum;

	Real xlo_viz, xhi_viz, ylo_viz, yhi_viz;

	Real dx_viz, dy_viz;

	inline Real W(Real lambda);
	void dumpOne(int num);

	Real *buffer;
	unsigned char *data;

public:
	SavePNG(string prefix, int vizx, int vizy);
	void prepare();

	void exec();
};

class Screen : public Saver
{
public:
	Screen() : Saver(&cout) {};

	void exec();
};










