/*
 * Savers.cpp
 *
 *  Created on: Dec 13, 2013
 *      Author: alexeedm
 */

#include <mpi.h>
#include <cmath>

#include "Savers.h"

void SaveNorms::exec()
{
	Diffusion* dif = dynamic_cast<Diffusion*>(sim);
	if (dif == NULL) return;

	Real myLinf = 0;
	Real myL1   = 0;
	Real myL2   = 0;

	Real Linf, L1, L2;
	int me;
	MPI_Comm_rank(MPI_COMM_WORLD, &me);

	for (int ix=0; ix < sim->mynx; ix++)
		for (int iy=0; iy < sim->myny; iy++)
		{
			Real error = (*dif->ping)(ix,iy) - dif->analytical(sim->myxlo + sim->dx*ix, sim->myylo + sim->dy*iy, sim->t);
			myLinf =  max(myLinf,abs(error));
			myL1   += abs(error);
			myL2   += error*error;
		}

	MPI_Reduce(&myLinf, &Linf, 1, sim->comm->type, MPI_MAX, 0, MPI_COMM_WORLD);
	MPI_Reduce(&myL1,   &L1,   1, sim->comm->type, MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&myL2,   &L2,   1, sim->comm->type, MPI_SUM, 0, MPI_COMM_WORLD);

	L2 = sqrt( L2/(sim->nx*sim->ny) );
	L1 /= (sim->nx*sim->ny);

	if (sim->comm->isMaster())
	{
		(*file) << Linf << " " << L1 << " " << L2 << endl;
		file->flush();
	}
}

void SaveTiming::exec()
{
	if (sim->comm->isMaster())
		(*file) << sim->profiler.printStat() << endl;
}

SavePNG::SavePNG(string prefix, int nx_viz, int ny_viz) :
prefix(prefix), nx_viz(nx_viz), ny_viz(ny_viz), imgNum(0) {};

void SavePNG::prepare()
{
	nQuantities = sim->nQuantities;
	stencil = 2;
	grid = new LocalGrid2D();
	sim->comm->localGrid(mynx_viz, myny_viz, xlo_viz, xhi_viz, ylo_viz, yhi_viz, nx_viz, ny_viz);

	dx_viz = (sim->xhi - sim->xlo) / nx_viz;
	dy_viz = (sim->yhi - sim->ylo) / ny_viz;

	int myghostx = abs((sim->myxlo - xlo_viz) / dx_viz) + 5*stencil;
	int myghosty = abs((sim->myxlo - xlo_viz) / dx_viz) + 5*stencil;
	MPI_Allreduce(&myghostx, &ghostx, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
	MPI_Allreduce(&myghosty, &ghosty, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);

	if (sim->comm->isMaster())
		grid->create(nx_viz, ny_viz, ghostx, ghosty);
	else
		grid->create(mynx_viz, myny_viz, ghostx, ghosty);

	buffer = new Real[(mynx_viz + 2*ghostx) * (myny_viz + 2*ghosty)];
	if (sim->comm->isMaster()) data = new unsigned char[nx_viz * ny_viz * 4];
}

inline Real SavePNG::W(Real lambda)
{
	lambda = abs(lambda);

	Real res = 0;
	res += (lambda < 1) ? 1 + lambda*lambda*(1.5*lambda - 2.5) : 0;
	res += (1 <= lambda && lambda < 2) ? 0.5 * (2 - lambda)*(2 - lambda) * (1 - lambda) : 0;
	return res;
}

void SavePNG::dumpOne(int num)
{
	for (int ix = -ghostx; ix < mynx_viz + ghostx; ix++)
		for (int iy = -ghosty; iy < myny_viz + ghosty; iy++)
			(*grid)(ix, iy) = 0;

	if (sim->comm->isMaster())
		for (int ix = 0; ix < nx_viz; ix++)
			for (int iy = 0; iy < ny_viz; iy++)
				(*grid)(ix, iy) = 0;

	for (int ix = 0; ix < sim->mynx; ix++)
		for (int iy = 0; iy < sim->myny; iy++)
		{
			Real x_h = (ix*sim->dx + sim->myxlo - xlo_viz) / dx_viz;
			Real y_h = (iy*sim->dy + sim->myylo - ylo_viz) / dy_viz;

			int vizx = (int) (x_h);
			int vizy = (int) (y_h);

			for (int sx = -stencil; sx <= stencil; sx++)
				for (int sy = -stencil; sy <= stencil; sy++)
				{
					(*grid)(vizx+sx, vizy+sy) += (*sim->pings[num])(ix, iy) * W(x_h - (vizx+sx)) * W(y_h - (vizy+sy));
				}
		}

	if (!sim->comm->isMaster())
	{
		int c=0;

		for (int ix = -ghostx; ix < mynx_viz + ghostx; ix++)
			for (int iy = -ghosty; iy < myny_viz + ghosty; iy++)
			{
				buffer[c++] = (*grid)(ix, iy);
			}

		MPI_Send(buffer, c, sim->comm->type, 0, 0, MPI_COMM_WORLD);
	}

	if (sim->comm->isMaster())
	{
		for (int n=1; n < sim->comm->nprocs; n++)
		{
			int ncoo[2];
			sim->comm->id2coo(ncoo, n);
			int neigh_nx = mynx_viz, neigh_ny = myny_viz;

			if (ncoo[0] == sim->comm->npx - 1) neigh_nx = nx_viz - (mynx_viz * (sim->comm->npx - 1));
			if (ncoo[1] == sim->comm->npy - 1) neigh_ny = ny_viz - (myny_viz * (sim->comm->npy - 1));

			MPI_Recv(buffer, (neigh_nx + 2*ghostx) * (neigh_ny + 2*ghosty), sim->comm->type, n, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

			int startx = ncoo[0] * mynx_viz;
			int starty = ncoo[1] * myny_viz;

			int c=0;
			for (int ix = startx - ghostx; ix < startx + neigh_nx + ghostx; ix++)
				for (int iy = starty - ghosty; iy < starty + neigh_ny + ghosty; iy++)
				{
					(*grid)(ix, iy) += buffer[c++];
				}
		}

		int c = 0;
		Real a = (Real)(nx_viz * ny_viz) / (sim->nx*sim->ny);
		a= 1;
        
        // find the value range
        Real low = (*grid)(0, 0);
        Real high = (*grid)(0, 0);
        for (int iy = ny_viz-1; iy >= 0; iy--)
			for (int ix = 0; ix < nx_viz; ix++)
            {
                low = std::min(low, (*grid)(ix, iy));
                high = std::max(high, (*grid)(ix, iy));
            }
            
		for (int iy = ny_viz-1; iy >= 0; iy--)
			for (int ix = 0; ix < nx_viz; ix++)
			{
                // rescale values into 0-4 range and convert to rgb ramp (see hsv->rbg conversion)
                Real value = 4.0 * ((*grid)(ix, iy)-low)/(high-low);
                Real r = std::max(std::min(std::max(2.0-value, value-4.0), 1.0), 0.0);
                Real g = std::max(std::min(std::min(value, 4.0-value), 1.0), 0.0);
                Real b = std::max(std::min(std::min(value-2.0, 6.0-value), 1.0), 0.0);
				data[c++] = 255 * r;
				data[c++] = 255 * g;
				data[c++] = 255 * b;
				data[c++] = 0xFFu;
			}

		char name[100];
		sprintf(name, "%s/%s_%05d_ch%02d.png", folder.c_str(), prefix.c_str(), imgNum, num);
		write_png(name, nx_viz, ny_viz, data);
	}
}

void SavePNG::exec()
{
	for (int i=0; i < nQuantities; i++)
		dumpOne(i);
	imgNum++;
}

void Screen::exec()
{
	if (sim->comm->isMaster())
	{
		(*file) << "Simulation time is now  " << sim->t << endl;
	}
}








