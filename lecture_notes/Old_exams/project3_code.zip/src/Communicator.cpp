/*
 * Communicator.cpp
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */

#include <cmath>
#include <iostream>

#include "Communicator.h"

using namespace std;

Communicator::Communicator(Real xlo, Real xhi, Real ylo, Real yhi, int ghostx, int ghosty) :
ghostx(ghostx), ghosty(ghosty), xlo(xlo), xhi(xhi), ylo(ylo), yhi(yhi)
{
	MPI_Comm_rank(MPI_COMM_WORLD, &me);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	type = (sizeof(Real) == 4) ? MPI_FLOAT : MPI_DOUBLE;

	npx = (int)round(sqrt(nprocs));
	npy = nprocs / npx;
	while (npx * npy != nprocs)
	{
		npx++;
		npy = nprocs / npx;
	}

	int tmp[2];
	id2coo(tmp, me);
	mex = tmp[0];
	mey = tmp[1];

	neighbors[0] = coo2idx(mex + 1, mey + 0);
	neighbors[1] = coo2idx(mex + 1, mey + 1);
	neighbors[2] = coo2idx(mex + 0, mey + 1);
	neighbors[3] = coo2idx(mex - 1, mey + 1);
	neighbors[4] = coo2idx(mex - 1, mey + 0);
	neighbors[5] = coo2idx(mex - 1, mey - 1);
	neighbors[6] = coo2idx(mex + 0, mey - 1);
	neighbors[7] = coo2idx(mex + 1, mey - 1);

	nmap[0] = 4;
	nmap[1] = 5;
	nmap[2] = 6;
	nmap[3] = 7;
	nmap[4] = 0;
	nmap[5] = 1;
	nmap[6] = 2;
	nmap[7] = 3;

	for (int i=0; i<8; i++)
		ghostNeighs[i] = 0;

	if (mex == 0)
		ghostNeighs[3] = ghostNeighs[4] = ghostNeighs[5] = 1;

	if (mex == npx)
		ghostNeighs[0] = ghostNeighs[1] = ghostNeighs[7] = 1;

	if (mey == 0)
		ghostNeighs[5] = ghostNeighs[6] = ghostNeighs[7] = 1;

	if (mey == npy)
		ghostNeighs[1] = ghostNeighs[2] = ghostNeighs[3] = 1;
}

void Communicator::localGrid(int &mynx,   int &myny,   Real &myxlo, Real &myxhi,
							 Real &myylo, Real &myyhi, int nx,      int ny)
{
	Real dx = (xhi-xlo) / nx;
	Real dy = (yhi-ylo) / ny;

	if (nx % npx == 0)
	{
		mynx  = nx / npx;
		myxlo = xlo +  mex    * mynx * dx;
		myxhi = xlo + (mex+1) * mynx * dx;
	}
	else
	{
		mynx  = (nx / npx) + 1;
		myxlo = xlo +  mex    * mynx * dx;
		myxhi = xlo + (mex+1) * mynx * dx;

		if (mex == npx - 1)
		{
			mynx  = nx - (mynx * (npx - 1));
			myxhi = xhi;
		}
	}

	if (ny % npy == 0)
	{
		myny  = ny / npy;
		myylo = ylo +  mey    * myny * dy;
		myyhi = ylo + (mey+1) * myny * dy;
	}
	else
	{
		myny  = (ny / npy) + 1;
		myylo = ylo +  mey    * myny * dy;
		myyhi = ylo + (mey+1) * myny * dy;

		if (mey == npy - 1)
		{
			myny  = ny - (myny * (npy - 1));
			myyhi = yhi;
		}
	}
}

void Communicator::prepareBufers(int nx, int ny, int nQuantities)
{
	// East
	sendStart[0][0] = nx - ghostx;
	sendEnd  [0][0] = nx;
	sendStart[0][1] = 0;
	sendEnd  [0][1] = ny;

	// North-East
	sendStart[1][0] = nx - ghostx;
	sendEnd  [1][0] = nx;
	sendStart[1][1] = ny - ghosty;
	sendEnd  [1][1] = ny;

	// North
	sendStart[2][0] = 0;
	sendEnd  [2][0] = nx;
	sendStart[2][1] = ny - ghosty;
	sendEnd  [2][1] = ny;

	// North-West
	sendStart[3][0] = 0;
	sendEnd  [3][0] = ghostx;
	sendStart[3][1] = ny - ghosty;
	sendEnd  [3][1] = ny;

	// West
	sendStart[4][0] = 0;
	sendEnd  [4][0] = ghostx;
	sendStart[4][1] = 0;
	sendEnd  [4][1] = ny;

	// South-West
	sendStart[5][0] = 0;
	sendEnd  [5][0] = ghostx;
	sendStart[5][1] = 0;
	sendEnd  [5][1] = ghosty;

	// South
	sendStart[6][0] = 0;
	sendEnd  [6][0] = nx;
	sendStart[6][1] = 0;
	sendEnd  [6][1] = ghosty;

	// South-East
	sendStart[7][0] = nx - ghostx;
	sendEnd  [7][0] = nx;
	sendStart[7][1] = 0;
	sendEnd  [7][1] = ghosty;

	// Receive limits
	// East
	recvStart[0][0] = nx;
	recvEnd  [0][0] = nx + ghostx;
	recvStart[0][1] = 0;
	recvEnd  [0][1] = ny;

	// North-East
	recvStart[1][0] = nx;
	recvEnd  [1][0] = nx + ghostx;
	recvStart[1][1] = ny;
	recvEnd  [1][1] = ny + ghosty;

	// North
	recvStart[2][0] = 0;
	recvEnd  [2][0] = nx;
	recvStart[2][1] = ny;
	recvEnd  [2][1] = ny + ghosty;

	// North-West
	recvStart[3][0] = -ghostx;
	recvEnd  [3][0] = 0;
	recvStart[3][1] = ny;
	recvEnd  [3][1] = ny + ghosty;

	// West
	recvStart[4][0] = -ghostx;
	recvEnd  [4][0] = 0;
	recvStart[4][1] = 0;
	recvEnd  [4][1] = ny;

	// South-West
	recvStart[5][0] = -ghostx;
	recvEnd  [5][0] = 0;
	recvStart[5][1] = -ghosty;
	recvEnd  [5][1] = 0;

	// South
	recvStart[6][0] = 0;
	recvEnd  [6][0] = nx;
	recvStart[6][1] = -ghosty;
	recvEnd  [6][1] = 0;

	// South-East
	recvStart[7][0] = nx;
	recvEnd  [7][0] = nx + ghostx;
	recvStart[7][1] = -ghosty;
	recvEnd  [7][1] = 0;

	sendBuffer = new Real**[nQuantities];
	recvBuffer = new Real**[nQuantities];

	for (int q=0; q<nQuantities; q++)
	{
		sendBuffer[q] = new Real*[8];
		recvBuffer[q] = new Real*[8];
		for (int i=0; i<8; i++)
		{
			const int N = (sendStart[i][0] - sendEnd[i][0]) * (sendStart[i][1] - sendEnd[i][1]);
			sendBuffer[q][i] = new Real[N];
			recvBuffer[q][i] = new Real[N];
		}
	}
}

void Communicator::exchangeGhosts(LocalGrid2D* grid, int q)
{
	for (int i=0; i<8; i++)
	{
		MPI_Irecv(recvBuffer[q][i], (sendStart[i][0] - sendEnd[i][0]) * (sendStart[i][1] - sendEnd[i][1]),
				  type, neighbors[i], nmap[i] + 8*q, MPI_COMM_WORLD, &reqs[i]);
	}

	for (int i=0; i<8; i++)
	{
		int c = 0;

		for (int ix = sendStart[i][0]; ix < sendEnd[i][0]; ix++)
			for (int iy = sendStart[i][1]; iy < sendEnd[i][1]; iy++)
			{
				sendBuffer[q][i][c++] = (*grid)(ix, iy);
			}
		MPI_Isend(sendBuffer[q][i], c, type, neighbors[i], i + 8*q, MPI_COMM_WORLD, &tmp);
	}
}

void Communicator::recvGhosts(LocalGrid2D* grid, int q)
{
	MPI_Waitall(8, reqs, MPI_STATUSES_IGNORE);

	for (int i=0; i<8; i++)
	{
		int c = 0;

		for (int ix = recvStart[i][0]; ix < recvEnd[i][0]; ix++)
			for (int iy = recvStart[i][1]; iy < recvEnd[i][1]; iy++)
			{
				(*grid)(ix, iy) = recvBuffer[q][i][c++] ;
			}
	}
}





