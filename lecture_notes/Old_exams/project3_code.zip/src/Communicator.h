/*
 * Communicator.h
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */


#pragma once

#include <mpi.h>

#include "misc.h"
#include "Simulation.h"

class LocalGrid2D;

class Communicator
{
	Real ***sendBuffer;
	Real ***recvBuffer;
	MPI_Request reqs[8];
	MPI_Request tmp;

public:
	MPI_Datatype type;

	int  me, nprocs;
	int  mex, mey;
	int  npx, npy;
	int  neighbors[8];
	int  nmap[8];
	int  ghostNeighs[8];
	int  sendStart[8][2];
	int  sendEnd[8][2];

	Real recvStart[8][2];
	Real recvEnd[8][2];

	int ghostx, ghosty;
	Real xlo, xhi,
		 ylo, yhi;

	int  coo2idx(int ix, int iy)
	{
		ix = (ix >= npx) ? ix - npx : ix;
		ix = (ix < 0)    ? ix + npx : ix;

		iy = (iy >= npy) ? iy - npy : iy;
		iy = (iy < 0)    ? iy + npy : iy;

		return ix * npy + iy;
	}
	void id2coo(int* ix, int id)
	{
		ix[0] = id / npy;
		ix[1] = id % npy;
	}

public:
	Communicator(Real xlo, Real xhi, Real ylo, Real yhi, int ghostx, int ghosty);
	void localGrid(int &mynx,   int &myny,   Real &myxlo, Real &myxhi,
				   Real &myylo, Real &myyhi, int nx,      int ny);
	void prepareBufers(int nx, int ny, int nQuantities=1);
	void exchangeGhosts(LocalGrid2D* grid, int q=0);
	void recvGhosts    (LocalGrid2D* grid, int q=0);
	bool isMaster() { return me == 0; }
};
