/*
 * simulation.h
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */

#pragma once

#include <list>

#include "misc.h"
#include "Communicator.h"
#include "Savers.h"
#include "Profiler.h"

using namespace std;

class Saver;
class Communicator;

class Grid2D
{
protected:
	Real* data;
	int nx, ny;

public:
	void create(int nx, int ny);
	Real& operator()(int ix, int iy);
};

class LocalGrid2D: public Grid2D
{
public:
	int ghostx, ghosty;

	void create(int nx, int ny, int ghostx, int ghosty);
	Real& operator()(int ix, int iy);
};

inline Real& Grid2D::operator ()(int ix, int iy)
{
	return data[ix*ny + iy];
}

inline Real& LocalGrid2D::operator ()(int ix, int iy)
{
	return Grid2D::operator()(ix + ghostx, iy + ghosty);
}


struct Kernel2D
{
	static const int stencil[2];
	Real epsilon, e_1, e_2, e_8, Ce_2, cut2;

	Kernel2D(Real epsilon, Real cut) : epsilon(epsilon), e_1(1.0/epsilon), e_2(1.0/(epsilon*epsilon))
	{
		//stencil[0] = -dist;
		//stencil[1] = dist;

		Ce_2 = 16 / (M_PI*M_PI) * e_2;
		cut2 = cut * cut;
		e_8  = e_2 * e_2 * e_2 * e_2;
	};

	inline Real operator()(Real x, Real y)
	{
		const Real IxI2 = x*x + y*y;

		//if (IxI2 > cut2) return 0;

		const Real IxI4  = IxI2 * IxI2;
		const Real IxI8  = IxI4 * IxI4;

		return Ce_2 / (IxI8 * e_8 + 1);
	}

	int  getMaxStencil() { return max( abs(stencil[0]), abs(stencil[1]) ); }
};

class Simulation
{
	friend class SaveNorms;
	friend class SaveTiming;
	friend class SavePNG;
	friend class Screen;

protected:
	int  nQuantities;
	int  nx, ny;
	int  mynx, myny;
	int  ghost;

	Real dx, dy;
	Real xlo, xhi,
		 ylo, yhi;
	Real dt;
	Real t;
	int iteration;

	Real myxlo, myxhi,
		 myylo, myyhi;

	Kernel2D kernel;
	LocalGrid2D** pings;
	LocalGrid2D** pongs;

	Communicator* comm;
	list<Saver*>	savers;

	Profiler profiler;

public:
	Simulation(int nx, int ny, Real xlo, Real xhi,
			   Real ylo, Real yhi, Real dt, Kernel2D kernel, int nQuantities);
	void registerSaver(Saver* saver, int period);
	void execSavers();
	void postExecSavers();

	virtual void initialize() = 0;
	virtual void step() = 0;
};

class Diffusion: public Simulation
{
	friend class SaveNorms;

	Real D;
	LocalGrid2D* ping;
	LocalGrid2D* pong;

	inline void updateVal(int ix, int iy);

public:
	Diffusion(int nx, int ny, Real xlo, Real xhi,
			  Real ylo, Real yhi, Real dt, Kernel2D kernel,
			  Real D);

	void step();
	void initialize();

	double analytical(Real x, Real y, Real t)
	{
		return sin(2*M_PI*x) * sin(2*M_PI*y) * exp(-8*t*M_PI*M_PI);
	}
};

class GrayScott: public Simulation
{
	Real Du;
	LocalGrid2D* uping;
	LocalGrid2D* upong;

	Real Dv;
	LocalGrid2D* vping;
	LocalGrid2D* vpong;

	Real F, k;

	inline void updateVal(int ix, int iy);

public:
	GrayScott(int nx, int ny, Real xlo, Real xhi,
			  Real ylo, Real yhi, Real dt, Kernel2D kernel,
			  Real Du, Real Dv, Real F, Real k);

	void step();
	void initialize();
};





