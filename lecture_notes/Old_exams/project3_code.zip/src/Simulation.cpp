/*
 * simulation.cpp
 *
 *  Created on: Dec 12, 2013
 *      Author: alexeedm
 */


#include "Simulation.h"

void Grid2D::create(int nx, int ny)
{
	this->nx = nx;
	this->ny = ny;

	data = new Real[nx*ny];
}

void LocalGrid2D::create(int nx, int ny, int ghostx, int ghosty)
{
	this->ghostx = ghostx;
	this->ghosty = ghosty;

	Grid2D::create(nx + 2*ghostx, ny + 2*ghosty);
}

//======================================================================================
// Abstract simulation
//======================================================================================

Simulation::Simulation(int nx, int ny, Real xlo, Real xhi, Real ylo, Real yhi,
					   Real dt, Kernel2D kernel, int nQuantities) :
xlo(xlo), xhi(xhi), ylo(ylo), yhi(yhi), nx(nx), ny(ny),
dt(dt), kernel(kernel), nQuantities(nQuantities)
{
	dx = (xhi-xlo) / nx;
	dy = (yhi-ylo) / ny;

	ghost = kernel.getMaxStencil();

	comm = new Communicator(xlo, xhi, ylo, yhi, ghost, ghost);
	comm->localGrid(mynx, myny, myxlo, myxhi, myylo, myyhi, nx, ny);
	comm->prepareBufers(mynx, myny, nQuantities);

	pings = new LocalGrid2D*[nQuantities];
	pongs = new LocalGrid2D*[nQuantities];

	for (int q=0; q < nQuantities; q++)
	{
		pings[q] = new LocalGrid2D();
		pings[q]->create(mynx, myny, ghost, ghost);

		pongs[q] = new LocalGrid2D();
		pongs[q]->create(mynx, myny, ghost, ghost);
	}

	t = 0;
	iteration = 0;
}

void Simulation::registerSaver(Saver* saver, int period)
{
	saver->setSimulation(this);
	saver->setPeriod(period);
	savers.push_back(saver);
}

void Simulation::execSavers()
{
	for (list<Saver*>::iterator it = savers.begin(), end = savers.end(); it != end; ++it)
	{
		if ((iteration % (*it)->getPeriod()) == 0) (*it)->exec();
	}
}

void Simulation::postExecSavers()
{
	for (list<Saver*>::iterator it = savers.begin(), end = savers.end(); it != end; ++it)
	{
		(*it)->exec();
	}
}

//======================================================================================
// Diffusion
//======================================================================================

Diffusion::Diffusion(int nx, int ny, Real xlo, Real xhi,
		  Real ylo, Real yhi, Real dt, Kernel2D kernel,
		  Real D) :
Simulation(nx, ny, xlo, xhi, ylo, yhi, dt, kernel, 1),
D(D)
{
	ping = pings[0];
	pong = pongs[0];
}

void Diffusion::initialize()
{
	for (int ix = 0; ix < mynx; ix++)
		for (int iy = 0; iy < myny; iy++)
			(*ping)(ix, iy) = analytical(myxlo + dx*ix, myylo + dy*iy, 0);
}

inline void Diffusion::updateVal(int ix, int iy)
{
	Real diff = 0;
	Real oldVal = (*ping)(ix, iy);

	double xx = kernel.stencil[0]*dx;
	for (int sx = kernel.stencil[0]; sx <= kernel.stencil[1]; sx++)
	{
		double yy = kernel.stencil[0]*dy;
		for (int sy = kernel.stencil[0]; sy <= kernel.stencil[1]; sy++)
		{
			diff += kernel(xx, yy) * ((*ping)(sx + ix, sy + iy) - oldVal);
			yy   += dy;
		}
		xx += dx;
	}

	(*pong)(ix, iy) = oldVal + dt * D * diff * dx * dy / (kernel.epsilon * kernel.epsilon);
	//printf("[%3d, %3d]:  %10.8f --> %10.8f\n", ix, iy, (*ping)(ix, iy), (*pong)(ix, iy));
	//printf("%f\n\n", diff);
}

void Diffusion::step()
{
	profiler.start("Requesting ghosts");
	{
		comm->exchangeGhosts(ping);
	}
	profiler.stop();

	profiler.start("Inner region");
	{
		for (int ix = ghost; ix < mynx - ghost; ix++)
			for (int iy = ghost; iy < myny - ghost; iy++)
				updateVal(ix, iy);
	}
	profiler.stop();

	profiler.start("Receiving ghosts");
	{
		comm->recvGhosts(ping);
	}
	profiler.stop();

	profiler.start("Border region");
	{
		for (int ix = 0; ix < mynx; ix++)
			for (int iy = 0; iy < myny; iy++)
			{
				if (iy == ghost && ix >= ghost && ix < mynx - ghost)
				{
					iy = myny - ghost;
				}
				updateVal(ix, iy);
			}
	}
	profiler.stop();

	swap(ping, pong);

	t += dt;
	iteration++;

	profiler.start("Savers");
	{
		execSavers();
	}
	profiler.stop();
}

//======================================================================================
// Reaction-diffusion
//======================================================================================

GrayScott::GrayScott(int nx, int ny, Real xlo, Real xhi,
					 Real ylo, Real yhi, Real dt, Kernel2D kernel,
					 Real Du, Real Dv, Real F, Real k) :
Simulation(nx, ny, xlo, xhi, ylo, yhi, dt, kernel, 2),
Du(Du), Dv(Dv), F(F), k(k)
{
	uping = pings[0];
	upong = pongs[0];

	vping = pings[1];
	vpong = pongs[1];
}

void GrayScott::initialize()
{
	srand48(comm->me);
	for (int ix = 0; ix < mynx; ix++)
		for (int iy = 0; iy < myny; iy++)
		{
			Real x = myxlo + dx*ix;
			Real y = myylo + dy*iy;

			if (x >= -0.2 && x <= 0.2  &&  y >= -0.2 && y <= 0.2)
			{
				(*uping)(ix, iy) = 0.5  + 0.01 * drand48();
				(*vping)(ix, iy) = 0.25 + 0.01 * drand48();
			}
			else
			{
				(*uping)(ix, iy) = 1;
				(*vping)(ix, iy) = 0;
			}
		}
}

inline void GrayScott::updateVal(int ix, int iy)
{
	Real diffu = 0;
	Real diffv = 0;
	Real oldU = (*uping)(ix, iy);
	Real oldV = (*vping)(ix, iy);

	double xx = kernel.stencil[0]*dx;
	for (int sx = kernel.stencil[0]; sx <= kernel.stencil[1]; sx++)
	{
		double yy = kernel.stencil[0]*dy;
		for (int sy = kernel.stencil[0]; sy <= kernel.stencil[1]; sy++)
		{
			Real K = kernel(xx, yy);
			diffu += K * ((*uping)(sx + ix, sy + iy) - oldU);
			diffv += K * ((*vping)(sx + ix, sy + iy) - oldV);
			yy   += dy;
		}
		xx += dx;
	}

	(*upong)(ix, iy) = oldU + dt * ( Du * diffu * dx * dy * kernel.e_2 - oldU*oldV*oldV + F*(1-oldU) );
	(*vpong)(ix, iy) = oldV + dt * ( Dv * diffv * dx * dy * kernel.e_2 + oldU*oldV*oldV - (F+k)*oldV );
}

void GrayScott::step()
{
	profiler.start("Requesting ghosts");
	{
		comm->exchangeGhosts(uping, 0);
		comm->exchangeGhosts(vping, 1);
	}
	profiler.stop();

	profiler.start("Inner region");
	{
		for (int ix = ghost; ix < mynx - ghost; ix++)
			for (int iy = ghost; iy < myny - ghost; iy++)
				updateVal(ix, iy);
	}
	profiler.stop();

	profiler.start("Receiving ghosts");
	{
		comm->recvGhosts(uping, 0);
		comm->recvGhosts(vping, 1);
	}
	profiler.stop();

	profiler.start("Border region");
	{
		for (int ix = 0; ix < mynx; ix++)
			for (int iy = 0; iy < myny; iy++)
			{
				if (iy == ghost && ix >= ghost && ix < mynx - ghost)
				{
					iy = myny - ghost;
				}
				updateVal(ix, iy);
			}
	}
	profiler.stop();

	swap(uping, upong);
	swap(vping, vpong);

	t += dt;
	iteration++;

	profiler.start("Savers");
	{
		execSavers();
	}
	profiler.stop();
}


