To compile on Brutus:
module load gcc/4.6
make

To test the code:
./main -steps <number of steps> -msg <message to display> -num <floating point number> -print <print flag> 

Example:
./main -steps 10 -msg Hello -num 0.5 -print 1





