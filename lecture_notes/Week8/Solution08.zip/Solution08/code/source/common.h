
#ifndef DirectVortexSolver_common_h
#define DirectVortexSolver_common_h

#include <iostream>
#include <vector>
#include <cmath>
#include <mpi.h>
#include "Timer.hpp"

#endif
